import PostForm from "../components/PostForm";
import { createPost } from "../api/api";
import { useNavigate } from "react-router-dom";

export default function CreatePost() {
  const navigate = useNavigate();

  const handleSubmit = async (postData) => {
    await createPost(postData);
    navigate("/");
  };

  return (
    <div>
      <h2>Create a New Post</h2>
      <PostForm onSubmit={handleSubmit} />
    </div>
  );
}
