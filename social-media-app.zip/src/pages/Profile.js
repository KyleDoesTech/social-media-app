export default function Profile() {
  return (
    <div>
      <h2>Your Profile</h2>
      <p>Username: student01</p>
      <p>Posts: 10</p>
      <p>Bio: React developer in training.</p>
    </div>
  );
}
