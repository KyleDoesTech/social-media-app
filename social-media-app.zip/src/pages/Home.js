import { useEffect, useState } from "react";
import { fetchPosts } from "../api/api";
import Post from "../components/Post";

export default function Home() {
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    fetchPosts().then(data => setPosts(data));
  }, []);

  return (
    <div>
      <h2>News Feed</h2>
      {posts.length === 0 ? <p>Loading...</p> : posts.map(p => <Post key={p.id} post={p} />)}
    </div>
  );
}
